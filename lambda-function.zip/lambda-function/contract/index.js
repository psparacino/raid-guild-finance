import abi from "./abi.js";
import address from "./address.js";

export { abi, address };

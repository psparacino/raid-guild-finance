const address = {
  MolochAddress: "0xfe1084bc16427e5eb7f13fc19bcd4e641f7d571f",
};

export default address;
